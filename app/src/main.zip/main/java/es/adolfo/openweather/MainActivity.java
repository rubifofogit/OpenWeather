package es.adolfo.openweather;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import es.adolfo.openweather.model.City;

public class MainActivity extends AppCompatActivity implements WeatherFragment.OnFragmentInteractionListener {


    private City mainCity;
    private City secondCity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(savedInstanceState!= null) {
            mainCity = (City) savedInstanceState.getSerializable("mainCity");
            secondCity = (City) savedInstanceState.getSerializable("secondCity");
        }
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        WeatherFragment mainFragment = WeatherFragment.newInstance(mainCity,"First");
        if(findViewById(R.id.second)==null) {
            fragmentTransaction.replace(R.id.main,mainFragment);
        }
        else {
            fragmentTransaction.replace(R.id.main, mainFragment);
            WeatherFragment secondFragment = WeatherFragment.newInstance(secondCity,"Second");
            fragmentTransaction.replace(R.id.second,secondFragment);
        }
        fragmentTransaction.commit();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("mainCity",mainCity);
        outState.putSerializable("secondCity",secondCity);

    }

    @Override
    public void onFragmentInteraction(City city,int id) {
        if(id == R.id.main) {
            mainCity = city;
        }
        else {
            secondCity = city;
        }
    }
}
