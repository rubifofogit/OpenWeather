package es.adolfo.openweather;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import es.adolfo.openweather.model.City;
import es.adolfo.openweather.model.Weather;
import es.adolfo.openweather.task.WeatherTask;


public class WeatherFragment extends Fragment implements WeatherTask.AsyncResponse {

    private static final String ARG_PARAM1 = "city";
    private static final String ARG_PARAM2 = "param2";

    private boolean first = true;

    private City city;
    private String appid = "f34aa163c9c1a53db7404ed0f25f8b51";
    private String locale;

    private Spinner spinner;
    private Button button;
    private TableLayout table;
    private TextView cityWeather;
    private TextView temperature;
    private ImageView icon;

    private OnFragmentInteractionListener mListener;

    public WeatherFragment() {
        // Required empty public constructor
    }

    public static WeatherFragment newInstance(City city, String appid) {
        WeatherFragment fragment = new WeatherFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PARAM1, city);
        args.putString(ARG_PARAM2, appid);
        fragment.setArguments(args);
        fragment.locale = Locale.getDefault().getCountry();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
        if (getArguments() != null) {
            city = (City) getArguments().getSerializable(ARG_PARAM1);
            //appid = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_weather, container, false);
        spinner = (Spinner) view.findViewById(R.id.spinner);
        table = (TableLayout) view.findViewById(R.id.table);
        cityWeather = (TextView) view.findViewById(R.id.cityWeather);
        temperature = (TextView) view.findViewById(R.id.temperature);
        icon = (ImageView) view.findViewById(R.id.icon);

        DataBaseModel dataBaseModel = DataBaseModel.getInstance(getActivity());
        dataBaseModel.open();
        ArrayAdapter<City> adapter = new ArrayAdapter<City>(getActivity(),
                 android.R.layout.simple_spinner_item,dataBaseModel.getCityByProv("28"));
        dataBaseModel.close();
        int position = adapter.getPosition(city);
        Log.d("onCreateView",getArguments().toString());
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                City city = (City) parent.getItemAtPosition(position);
                if(!first) {
                    onSelected(city);
                }
                else {
                    first = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinner.setSelection(position);
        button = (Button) view.findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WeatherTask weatherTask = new WeatherTask();
                weatherTask.setDelegate(WeatherFragment.this);
                city =  (City) spinner.getSelectedItem();
                weatherTask.execute(city.getId(),appid,locale);
            }
        });
        return view;
    }

    public void onSelected(City city) {
        if (mListener != null) {
            mListener.onFragmentInteraction(city,this.getId());
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (activity instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) activity;
        } else {
            throw new RuntimeException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void processFinish(Weather weather) {
        populateTable(weather);
    }

    private void populateTable(Weather weather) {

        String cityWeatherValue = String.format(getString(R.string.city_weather_label),city );
        cityWeather.setText(cityWeatherValue);
        icon.setImageResource(getResources().getIdentifier("i" + weather.getConditions().get(0).getIcon()
                ,"drawable",getActivity().getPackageName()));
        String temperatureValue = String.format(getString(R.string.temperature_constant),
                weather.getMain().getTemp());
        temperature.setText(temperatureValue);
        TextView windValue = (TextView) table.findViewById(R.id.windValue);
        TextView skyValue = (TextView) table.findViewById(R.id.skyValue);
        TextView pressureValue = (TextView) table.findViewById(R.id.pressureValue);
        TextView humidityValue = (TextView) table.findViewById(R.id.humidityValue);
        TextView sunriseValue = (TextView) table.findViewById(R.id.sunriseValue);
        TextView sunsetValue = (TextView) table.findViewById(R.id.sunsetValue);
        windValue.setText(weather.getWind().getSpeed().toString());
        skyValue.setText(weather.getConditions().get(0).getDescription());
        pressureValue.setText(weather.getMain().getPressure().toString());
        humidityValue.setText(weather.getMain().getHumidity().toString());
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(weather.getSys().getSunrise());
        sunriseValue.setText(formatter.format(calendar.getTime()));
        calendar = Calendar.getInstance();
        calendar.setTimeInMillis(weather.getSys().getSunset());
        sunsetValue.setText(formatter.format(calendar.getTime()));
    }


    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(City city,int id);
    }
}
